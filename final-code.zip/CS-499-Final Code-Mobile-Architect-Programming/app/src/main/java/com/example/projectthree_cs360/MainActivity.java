package com.example.projectthree_cs360;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button loginButton;
    private Button createAccountButton;

    private Controller controller; // Moved to class level

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UserModel userModel = new UserModel(this);
        controller = new Controller(userModel); // Assigning to class-level controller

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setEnabled(false);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                loginButton.setEnabled(!username.getText().toString().isEmpty() &&
                        !password.getText().toString().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        username.addTextChangedListener(textWatcher);
        password.addTextChangedListener(textWatcher);
    }

    public void onLogin(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        controller.handleLogin(user, pass, this);
    }

    public void onCreateAccount(View view) {
        String user = username.getText().toString();
        String pass = password.getText().toString();
        controller.handleAccountCreation(user, pass, this);
    }

    public void onRequestSmsPermission(View view) {
        Intent intent = new Intent(this, SMSPermissionActivity.class);
        startActivity(intent);
    }

}
