package com.example.projectthree_cs360;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private Context context;
    private ArrayList<InventoryItem> itemList;
    private DatabaseHelper db;

    public InventoryAdapter(Context context, ArrayList<InventoryItem> itemList, DatabaseHelper db) {
        this.context = context;
        this.itemList = itemList;
        this.db = db;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName, itemQuantity;
        Button editButton, deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    @NonNull
    @Override
    public InventoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull InventoryAdapter.ViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText("Quantity: " + item.getQuantity());
        holder.editButton.setText("Add Quantity");

        holder.editButton.setOnClickListener(v -> {
            item.setQuantity(item.getQuantity() + 1);
            db.updateItem(item);
            notifyItemChanged(holder.getAdapterPosition());
            Toast.makeText(context, "Quantity updated for " + item.getName(), Toast.LENGTH_SHORT).show();
        });

        holder.deleteButton.setOnClickListener(v -> {
            db.deleteItem(item.getId()); // removing from database
            int pos = holder.getAdapterPosition();
            itemList.remove(pos);        // removing from list
            notifyItemRemoved(pos);      // updating UI
            Toast.makeText(context, "Deleted " + item.getName(), Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }
}
