package com.example.projectthree_cs360;
import android.content.Context;

public class UserModel {
    private DatabaseHelper db;

    public UserModel(Context context) {
        db = new DatabaseHelper(context);
    }

    public boolean validateUser(String username, String password) {
        return db.checkUser(username, password);
    }

    public boolean registerUser(String username, String password) {
        return db.insertUser(username, password);
    }
}
