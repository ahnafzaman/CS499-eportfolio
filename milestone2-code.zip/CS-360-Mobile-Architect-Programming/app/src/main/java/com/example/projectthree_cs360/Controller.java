package com.example.projectthree_cs360;

import android.content.Context;
import android.widget.Toast;
import android.content.Intent;

public class Controller {
    private UserModel userModel;

    public Controller(UserModel userModel) {
        this.userModel = userModel;
    }

    public void handleLogin(String username, String password, Context context) {
        if (userModel.validateUser(username, password)) {
            Toast.makeText(context, "Login successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(context, DataDisplayActivity.class);
            context.startActivity(intent);
        } else {
            Toast.makeText(context, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    public void handleAccountCreation(String username, String password, Context context) {
        if (userModel.registerUser(username, password)) {
            Toast.makeText(context, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Account creation failed", Toast.LENGTH_SHORT).show();
        }
    }
}

