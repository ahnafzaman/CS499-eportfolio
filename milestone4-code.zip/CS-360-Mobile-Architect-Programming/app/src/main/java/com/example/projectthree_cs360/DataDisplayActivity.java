package com.example.projectthree_cs360;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class DataDisplayActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemList = db.getAllItems();
        adapter = new InventoryAdapter(this, itemList, db);
        recyclerView.setAdapter(adapter);
    }

    public void onAddData(View view) {
        EditText nameInput = findViewById(R.id.inputItemName);
        EditText quantityInput = findViewById(R.id.inputQuantity);

        String name = nameInput.getText().toString().trim();
        String qtyText = quantityInput.getText().toString().trim();

        if (name.isEmpty() || qtyText.isEmpty()) {
            Toast.makeText(this, "Please enter both name and quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = Integer.parseInt(qtyText);
        InventoryItem newItem = new InventoryItem(0, name, quantity);

        db.insertItem(newItem);
        itemList.add(newItem);
        adapter.notifyItemInserted(itemList.size() - 1);

        Toast.makeText(this, "Item Added", Toast.LENGTH_SHORT).show();

        nameInput.setText("");
        quantityInput.setText("");
    }

    public void onFindItem(View view) {
        EditText searchInput = findViewById(R.id.searchInput);
        String name = searchInput.getText().toString().trim();

        InventoryItem item = db.getItemByName(name);

        if (item != null) {
            Toast.makeText(this, "Found: " + item.getName(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Item was not found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}


